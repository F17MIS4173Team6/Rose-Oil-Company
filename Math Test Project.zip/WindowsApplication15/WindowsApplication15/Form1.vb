﻿Public Class Form1
    Dim R As New Random
    Dim A As Integer = 0
    Dim counter As Integer = 0
    Dim S As Integer = 0
    Dim thisdate As Date = Today

 

    Public Sub Generate()
        Dim R As New Random
        Dim Q As Integer = R.Next(1, 11)
        Dim newitem As String


        If Q = 1 Then
            Me.Label1.Text = "What is 55 / 11?"
            A = 5
            newitem = Me.Label1.Text & " Answer: " & A
            Me.ListBox1.Items.Add(newitem)

        ElseIf Q = 2 Then
            Me.Label1.Text = "What is 100 / 10"
            A = 10
            newitem = Me.Label1.Text & " Answer: " & A
            Me.ListBox1.Items.Add(newitem)

        ElseIf Q = 3 Then
            Me.Label1.Text = "What is the next Number in the sequence - 2, 4, 6, 8 ...?"
            A = 10
            newitem = Me.Label1.Text & " Answer: " & A
            Me.ListBox1.Items.Add(newitem)
        ElseIf Q = 4 Then
            Me.Label1.Text = "What is the square root of 64?"
            A = 8
            newitem = Me.Label1.Text & " Answer: " & A
            Me.ListBox1.Items.Add(newitem)
        ElseIf Q = 5 Then
            Me.Label1.Text = "How many miles will you travel in 10 minutes if your speed is 60 miles an hour?"
            A = 6
            newitem = Me.Label1.Text & " Answer: " & A
            Me.ListBox1.Items.Add(newitem)
        ElseIf Q = 6 Then
            Me.Label1.Text = "What percent is 1/4?"
            A = 25
            newitem = Me.Label1.Text & " Answer: " & A
            Me.ListBox1.Items.Add(newitem)
        ElseIf Q = 7 Then
            Me.Label1.Text = "What is 9 times 15?"
            A = 135
            newitem = Me.Label1.Text & " Answer:  " & A
            Me.ListBox1.Items.Add(newitem)
        ElseIf Q = 8 Then
            Me.Label1.Text = "What is 5 squared?"
            A = 25
            newitem = Me.Label1.Text & " Answer: " & A
            Me.ListBox1.Items.Add(newitem)
        ElseIf Q = 9 Then
            Me.Label1.Text = "What is 9 divided by 3?"
            A = 3
            newitem = Me.Label1.Text & " Answer: " & A
            Me.ListBox1.Items.Add(newitem)
        ElseIf Q = 10 Then
            Me.Label1.Text = "If you have two baskets with 10 apples in each of them. How many apples do you have?"
            A = 20
            newitem = Me.Label1.Text & " Answer: " & A
            Me.ListBox1.Items.Add(newitem)





        End If

    End Sub
    Private Sub FileToolStripMenuItem_Click(sender As Object, e As EventArgs)
        

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Form2.Show()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        MsgBox("Thank you for Taking the Test")
        Me.Button3.Visible = False
        Me.MenuStrip1.Visible = False
        Me.Label1.Visible = False
        Me.Button1.Visible = False
        Me.TextBox1.Visible = False
        Me.Label2.Visible = False
        Me.Button4.Visible = False
        Me.Button2.Visible = True
        Me.ListBox1.Items.Clear()

        Me.ListBox1.Visible = False



    End Sub

    Private Sub NewTestToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NewTestToolStripMenuItem.Click
        Me.Button4.Visible = False
        Me.Button1.Visible = True
        Me.TextBox1.Visible = True
        Me.TextBox1.Clear()
        Me.TextBox1.Focus()
        Me.Label2.Visible = True

        Me.Label1.Visible = True
        Me.ListBox1.Items.Clear()
        Me.ListBox1.Visible = False
        S = 0
        counter = 0
        Generate()
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Database1DataSet1.score' table. You can move, or remove it, as needed.
        Me.ScoreTableAdapter1.Fill(Me.Database1DataSet1.score)
        'TODO: This line of code loads data into the 'Database1DataSet.users' table. You can move, or remove it, as needed.
        Me.UsersTableAdapter.Fill(Me.Database1DataSet.users)
        'TODO: This line of code loads data into the 'Database1DataSet.score' table. You can move, or remove it, as needed.

        MenuStrip1.Visible = False
        Me.Button4.Visible = False
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        counter += 1

        If counter >= 3 Then
            Testover()

        ElseIf Val(TextBox1.Text) = A And counter <= 3 Then
            S += 10
            MsgBox("Correct your Score is " & S)
            Me.TextBox1.Clear()
            Generate()
        Else
            MsgBox("Incorrect")
            Me.TextBox1.Clear()
            Generate()

            End If

        Me.TextBox1.Focus()







    End Sub
    Sub Testover()
        Me.Label1.Visible = False


        Me.Button1.Hide()
        Me.Button4.Visible = True
        Me.TextBox1.Hide()
        If Val(TextBox1.Text) = A Then
            S += 10
            MsgBox("Test Complete-Score = " & S)
        Else
            MsgBox("Incorrect" & S)
        End If

        Me.ListBox1.Enabled = False
        Me.ListBox1.Visible = True



    End Sub


    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click

        Dim x As Database1DataSet1.scoreRow = Me.Database1DataSet1.score.NewRow


        x.Username = Me.Label3.Text
        x.testtime = Today
        x.Score = S

        Me.Database1DataSet1.score.AddscoreRow(x)
        Me.ScoreTableAdapter1.Update(Me.Database1DataSet1.score)
        MsgBox("You have added your Score")
    End Sub

    

    Private Sub AboutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutToolStripMenuItem.Click
        Form4.Show()
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Dim response As MsgBoxResult
        response = MsgBox("Are you sure you want to exit the program?", MsgBoxStyle.Question + MsgBoxStyle.YesNo, "Confirm")
        If response = MsgBoxResult.Yes Then
            Me.Dispose()
        ElseIf response = MsgBoxResult.No Then
            Exit Sub
        End If
    End Sub

    Private Sub ScoreToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ScoreToolStripMenuItem.Click
        Form6.Show()

    End Sub
End Class
