﻿Public Class Form6

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub Form6_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Database1DataSet1.score' table. You can move, or remove it, as needed.
        Me.ScoreTableAdapter.Fill(Me.Database1DataSet1.score)

    End Sub

    
End Class