﻿Public Class Form2



    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Database1DataSet.users' table. You can move, or remove it, as needed.
        Me.UsersTableAdapter.Fill(Me.Database1DataSet.users)

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim login As Database1DataSet.usersRow = Nothing
        login = Me.Database1DataSet.users.FindByUsername(Me.TextBox1.Text)

        If login Is Nothing Then
            MsgBox("Login Failed")
        Else
            If login.Password = Me.TextBox2.Text Then
                MsgBox("Welcome " & login.Username)
                Form1.Button1.Visible = False
                Form1.Button2.Visible = False
                Form1.Button3.Visible = True
                Form1.Label2.Text = "Welcome " & Me.TextBox1.Text
                Form1.MenuStrip1.Visible = True
                Form1.TextBox1.Visible = False
                Form1.Label3.Text = Me.TextBox1.Text
                Me.Close()


            Else
                MsgBox("Login Failed")
                TextBox1.Clear()
                TextBox2.Clear()
                TextBox1.Focus()


            End If

        End If
    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Me.Close()
        Form3.Show()
    End Sub
End Class