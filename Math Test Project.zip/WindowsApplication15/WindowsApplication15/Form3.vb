﻿Public Class Form3

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Me.Close()
        Form2.Show()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim x As Database1DataSet.usersRow = Me.Database1DataSet.Users.NewRow()

        x.Username = Me.TextBox1.Text
        x.Password = Me.TextBox2.Text
        x.Email = Me.TextBox3.Text

        Me.Database1DataSet.users.AddusersRow(x)


        Me.UsersTableAdapter.Update(Me.Database1DataSet.users)
        MsgBox("You have Sucessfully Registered")
    End Sub

    Private Sub BindingSource1_CurrentChanged(sender As Object, e As EventArgs) Handles BindingSource1.CurrentChanged

    End Sub

    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Database1DataSet.users' table. You can move, or remove it, as needed.
        Me.UsersTableAdapter.Fill(Me.Database1DataSet.users)

    End Sub
End Class